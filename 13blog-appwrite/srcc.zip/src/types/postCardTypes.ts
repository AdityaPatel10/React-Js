export default interface postCardTypes{
    $id?: string;
    title?: string;
    featuredImg?: string;
}