export interface databaseTypes {
  title?: string;
  slug?: string;
  content?: string;
  featuredImg?: string;
  status?: string;
  userId?: string;
}
