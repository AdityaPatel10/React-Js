export interface signUpTypes {
  email: string;
  password: string;
  name: string;
}
export interface loginTypes {
  email: string;
  password: string;
}