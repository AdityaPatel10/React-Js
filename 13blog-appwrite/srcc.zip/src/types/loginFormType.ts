export default interface LoginFormTypes{
    email: string;
    password: string;
  }