export default interface signUpFormTypes{
    name: string;
    email: string;
    password: string;
}